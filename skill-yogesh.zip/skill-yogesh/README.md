## About
Testing Mycroft skill development - reveals yogesh's true nature

## Examples
* "Yogesh"
* "Yogi"

## Credits
Mycroft AI (@MycroftAI)

## Category
**Configuration**

## Tags
#yogesh